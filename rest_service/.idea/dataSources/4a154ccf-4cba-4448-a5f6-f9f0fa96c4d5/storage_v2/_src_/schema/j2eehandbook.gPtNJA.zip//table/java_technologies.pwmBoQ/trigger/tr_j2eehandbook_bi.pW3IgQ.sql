create trigger tr_j2eehandbook_bi
  before INSERT
  on java_technologies
  for each row
  BEGIN
    IF NEW.tech_name = '' THEN
      SIGNAL SQLSTATE '45001' SET MESSAGE_TEXT = 'Blank value on j2eehandbook.tech_name';
    END IF;
  END;

