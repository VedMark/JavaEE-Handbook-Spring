create trigger tr_j2eehandbook_bd
  after DELETE
  on java_technologies
  for each row
  BEGIN
    DECLARE v_count int;

    SELECT count(*)
    FROM java_technologies
    WHERE versions = OLD.versions
    GROUP BY versions
    INTO v_count;

    IF v_count IS NULL THEN
      DELETE FROM used_versions
      WHERE used_versions_id = OLD.versions;
    END IF ;
  END;

